Config = Config or {}

Config.BaseStateInterestRatePercent = 5 -- base rate
Config.StateDebtPercentageIntervals = 1000000 -- $50k USD debt = 1% increase on base rate
Config.DownpaymentRequirement = 35 -- percentage of total amount required by civ
Config.MaximumCivilianInterestRate = 50 -- max interest % for civs
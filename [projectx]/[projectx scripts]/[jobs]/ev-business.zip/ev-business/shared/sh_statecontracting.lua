BUILDING_TO_TEXT = {
  { model = 'shop', name = 'Shop' },
  { model = 'ex_int_office_03b_dlc', name = 'Office' },
  { model = 'nopixel_trailer', name = 'Trailer' },
  { model = 'v_int_16_low', name = 'Flat' },
  { model = 'v_int_16_mid_empty', name = 'House' },
  { model = 'v_int_24', name = 'Large House' },
  { model = 'v_int_44_empty', name = 'Mansion' },
  { model = 'v_int_49_empty', name = 'Motel' },
  { model = 'v_int_61', name = 'Bungalow' },
  { model = 'ghost_stash_houses_01', name = 'Warehouse' },
  { model = 'np_warehouse_3', name = 'Large Warehouse' },
}
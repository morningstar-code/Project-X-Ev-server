Config = {}

-- 30%
Config.DownpaymentRequirement = 0.3
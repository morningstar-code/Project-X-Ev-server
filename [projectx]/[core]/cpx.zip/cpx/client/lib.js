(function () {
    'use strict';
  
    const _0x53cddd = {
      "nyBlr": function (_0x34af93, _0x5c874f) {
        return _0x34af93 === _0x5c874f;
      },
      "Gbhhc": "distance",
      "GPYve": function (_0x2aa08a, _0x877811, _0x12600d, _0x4903ab) {
        return _0x2aa08a(_0x877811, _0x12600d, _0x4903ab);
      },
      "JLOqX": "area",
      "NuJfs": function (_0x2b53bb, _0x150273, _0x25a643, _0x55b331, _0x10e582, _0x140730) {
        return _0x2b53bb(_0x150273, _0x25a643, _0x55b331, _0x10e582, _0x140730);
      },
      "TAQgl": "radius",
      "bFsht": function (_0x208559, _0x45a3bf) {
        return _0x208559 === _0x45a3bf;
      },
      "zpKlS": "UHTOC",
      "cbdaA": "pickup",
      "UKpHs": function (_0x2ce8f2, _0x552fd6) {
        return _0x2ce8f2(_0x552fd6);
      },
      "VYKvw": "entity",
      "wxSDV": "nTozf",
      "cYxVI": "Invalid Blip Type",
      "bVAfT": "MXorD",
      "rmkqQ": function (_0x5387c8, _0x252183, ..._0x1c6566) {
        return _0x5387c8(_0x252183, ..._0x1c6566);
      },
      "GQpEV": "cpx_interact",
      "RCnUm": "BxKzg",
      "FZtbf": "2|0|6|5|4|3|1",
      "GwHme": "string",
      "AdZFR": "STRING",
      "ZnlzZ": function (_0xe762c8, _0x297303) {
        return _0xe762c8 === _0x297303;
      },
      "ceXSd": function (_0x4a4eae, _0xd190a7, _0x23eb9a) {
        return _0x4a4eae(_0xd190a7, _0x23eb9a);
      },
      "EIgdJ": function (_0x138498, _0x582782) {
        return _0x138498 === _0x582782;
      },
      "qQKbQ": function (_0x291cc2, _0xcadad4) {
        return _0x291cc2 !== _0xcadad4;
      },
      "hNkCm": "IvqJt",
      "ucqwR": "get",
      "ROWEN": "reset",
      "PJrjp": "SReln",
      "OlFyq": function (_0x2feeb4, _0x564433) {
        return _0x2feeb4 - _0x564433;
      },
      "dFUCf": function (_0x34c768) {
        return _0x34c768();
      },
      "UWYRv": function (_0x17d274, _0x1c6f82) {
        return _0x17d274(_0x1c6f82);
      },
      "aMVnQ": "HdGXa",
      "JckDL": "HDgoW",
      "rXaXr": function (_0x48d33f, _0x373ad5) {
        return _0x48d33f + _0x373ad5;
      },
      "lvNbB": "-enter",
      "KWpNw": function (_0xce337f, _0x196980) {
        return _0xce337f !== _0x196980;
      },
      "RVlZE": "-exit",
      "VVliM": function (_0x33a2e4, _0x434ec6) {
        return _0x33a2e4 !== _0x434ec6;
      },
      "KZMzc": function (_0x4b3140, _0x5341a4, _0x285e01) {
        return _0x4b3140(_0x5341a4, _0x285e01);
      },
      "jCsrL": function (_0x42ade4, _0x1b4ad0) {
        return _0x42ade4 < _0x1b4ad0;
      },
      "jtMRU": function (_0xac85e4, _0x587248, _0x29736c, _0x386184) {
        return _0xac85e4(_0x587248, _0x29736c, _0x386184);
      },
      "QoWxf": function (_0x29d0ad, _0x4d8e2e, _0x560170, _0x4cca61, _0x75be79) {
        return _0x29d0ad(_0x4d8e2e, _0x560170, _0x4cca61, _0x75be79);
      },
      "MEzwj": function (_0x5a48e5, _0x5a1e61) {
        return _0x5a48e5(_0x5a1e61);
      },
      "ctoLf": function (_0x235d94, _0x2816a3) {
        return _0x235d94 + _0x2816a3;
      },
      "HgEsl": "__cpx_req:",
      "FkZWi": function (_0x5e8485, _0x567da1) {
        return _0x5e8485 !== _0x567da1;
      },
      "oSMmQ": "HITlh",
      "RrYsk": "[RPC] Executing procedure:",
      "qCJUQ": function (_0x9ea551, _0x27ecec) {
        return _0x9ea551(_0x27ecec);
      },
      "XVHJc": function (_0x287694) {
        return _0x287694();
      },
      "KHAJf": "type",
      "EuFEf": "src",
      "NwPJp": "emitNet",
      "mXiMB": "encodePayload",
      "iFVsv": function (_0x6b04db, _0x322369) {
        return _0x6b04db(_0x322369);
      },
      "EXFdt": "resolve",
      "TQQwI": "reject",
      "TrVXD": "pfARb",
      "DzMts": "GetLibrary",
      "kcPXH": function (_0x34dc50, _0x174dc0) {
        return _0x34dc50(_0x174dc0);
      },
      "noScS": function (_0x167edc, _0x523b74) {
        return _0x167edc(_0x523b74);
      },
      "SiPVe": "5|6|3|2|4|0|1",
      "RdJbL": function (_0x39b7f4, _0x496e34, _0x15c430) {
        return _0x39b7f4(_0x496e34, _0x15c430);
      },
      "Iatjb": function (_0x4af67d, _0x1424b2) {
        return _0x4af67d(_0x1424b2);
      },
      "LRFrv": "number",
      "cBFpB": function (_0x4ca143, _0x497fe6, _0x120fee) {
        return _0x4ca143(_0x497fe6, _0x120fee);
      },
      "jAyAY": "boolean",
      "bSgfR": function (_0x82defb, _0x444e48, _0x1c7a3d) {
        return _0x82defb(_0x444e48, _0x1c7a3d);
      },
      "ENKoA": function (_0x10cec6, _0x222542) {
        return _0x10cec6 === _0x222542;
      },
      "gfjBk": function (_0x5b52ce, _0x4eb99d, _0x5878f8) {
        return _0x5b52ce(_0x4eb99d, _0x5878f8);
      },
      "ZAlhC": function (_0x237ac9, _0x1075c9) {
        return _0x237ac9 / _0x1075c9;
      },
      "TkDEB": "waHsP",
      "rfVRU": function (_0x545228, _0x4379aa) {
        return _0x545228 * _0x4379aa;
      },
      "ImitJ": "ckvXo",
      "ubSiu": "lastUpdated",
      "FnGgq": "VZOnu",
      "gkinl": function (_0x1e2995, _0x454de4) {
        return _0x1e2995 + _0x454de4;
      },
      "XgzFl": "timeout",
      "MrHoz": function (_0x42ca75, _0x447efb, _0x5e367a, _0x4515ec) {
        return _0x42ca75(_0x447efb, _0x5e367a, _0x4515ec);
      },
      "AgyXY": "ZulcE",
      "NzwXx": "VebDF",
      "rVCix": "data",
      "FHBSy": "cpx_polyzone",
      "hoJfp": "yhisW",
      "dXsEo": "solvA",
      "Dincx": "aQqRW",
      "Ujvbx": "ihLHT",
      "gdSCj": "waitForCondition",
      "qsTDi": "object",
      "eaJmx": "kFSsN",
      "tJxhz": "PPghJ",
      "SvNen": "LZeVS",
      "LXfKA": function (_0x5f4a4f, _0x273403) {
        return _0x5f4a4f + _0x273403;
      },
      "MqjTC": "bLjfA",
      "dwgbA": "decodePayload",
      "DpSZe": "__cpx_res:",
      "UdLfG": "emit",
      "PdDTT": function (_0x1f36aa, _0x1cae76, _0x1ea38f, _0x12f496) {
        return _0x1f36aa(_0x1cae76, _0x1ea38f, _0x12f496);
      },
      "Dkndn": "sUlql",
      "AYMff": "cpx_taskbar",
      "BZFaq": function (_0xe6dcff, _0x157145) {
        return _0xe6dcff === _0x157145;
      },
      "MHLYv": "cpx_phone",
      "jMyMW": "mesxQ",
      "JcaUD": "",
      "xVgZP": "createBlip",
      "YaCsl": "getMapRange",
      "RQPtM": "getDistance",
      "xGGJI": "getRandomNumber",
      "LtlRS": "cacheableMap",
      "VofHH": function (_0x1174b2, _0x30c600, _0x1f45fa) {
        return _0x1174b2(_0x30c600, _0x1f45fa);
      },
      "HApPb": "cpx_polyzone:enter",
      "deFNH": "cpx_polyzone:exit",
      "wDbmP": "onEnter",
      "KEqBX": "addBoxZone",
      "kuYdB": "addBoxTarget",
      "dCCgm": "loadAnim",
      "WqjPs": "loadWeaponAsset",
      "kdFDO": "loadNamedPtfxAsset",
      "urFZY": "onNet",
      "lqNNG": "register",
      "Qsemu": "execute",
      "vBcMq": "addPeekEntryByTarget",
      "SYaQQ": "addPeekEntryByFlag",
      "taRqT": "taskBar",
      "gsGBU": "phoneNotification",
      "lspWj": "Events",
      "keZRm": "Procedures",
      "pHlMO": "Streaming",
      "Wjqmx": "Utils",
      "TUaWA": "Interface",
      "PJbUF": "oaNSz",
      "UYAwo": "AOcYx",
      "ZqfJM": "return this",
      "ZOGUA": function (_0x387768, _0x1e0d05) {
        return _0x387768 === _0x1e0d05;
      },
      "akZuN": "gcCYH",
      "iUOBm": function (_0x55fa3d, _0x4e2b27) {
        return _0x55fa3d + _0x4e2b27;
      },
      "WoSgy": function (_0x37bb45, _0x26e50d) {
        return _0x37bb45 + _0x26e50d;
      },
      "wBBrh": function (_0x2ce02f, _0xd63cb) {
        return _0x2ce02f === _0xd63cb;
      }
    };
    var _0x3cf6c0 = {
      0x32: function (_0x5120b9, _0x5aa957, _0x275f08) {
        const _0x3f516e = {
          "kRAar": function (_0x51216e, _0x22ed7b) {
            return _0x51216e(_0x22ed7b);
          },
          "nhtDt": "STRING",
          "yWDzy": function (_0x5cdfe0, _0x498525) {
            return _0x5cdfe0(_0x498525);
          },
          "yENmm": function (_0x48bb7d, _0x339495) {
            return _0x48bb7d(_0x339495);
          },
          "vtKZW": "5|6|3|2|4|0|1",
          "IvUHr": function (_0x7cd761, _0x55fbda, _0x5895ea) {
            return _0x7cd761(_0x55fbda, _0x5895ea);
          },
          "COUwx": function (_0x2ef8e4, _0x35804d) {
            return _0x2ef8e4 === _0x35804d;
          },
          "PbQdh": "string",
          "NAoXm": function (_0x4cf1c4, _0x573109) {
            return _0x4cf1c4(_0x573109);
          },
          "hOXhw": "number",
          "vxgeR": function (_0x4b3ed1, _0x4c40b9, _0x381b80) {
            return _0x4b3ed1(_0x4c40b9, _0x381b80);
          },
          "lAfiO": "boolean",
          "lIFOV": function (_0x307e2c, _0x5540c0, _0x158aa2) {
            return _0x307e2c(_0x5540c0, _0x158aa2);
          },
          "gApNA": function (_0x45228d, _0xd22e13) {
            return _0x45228d === _0xd22e13;
          },
          "odiKw": function (_0xf58611, _0x23e267, _0x243862) {
            return _0xf58611(_0x23e267, _0x243862);
          },
          "oaoAC": function (_0x3acd5c, _0x14ce23) {
            return _0x3acd5c / _0x14ce23;
          },
          "LslRW": function (_0x47fea3, _0xb62a14) {
            return _0x47fea3 - _0xb62a14;
          },
          "eaURj": function (_0x3bbffa, _0x17d93c) {
            return _0x3bbffa(_0x17d93c);
          },
          "yKHLB": function (_0x1bde3d, _0x5a0d83) {
            return _0x1bde3d > _0x5a0d83;
          },
          "GlgyS": function (_0x26aab6, _0x923360) {
            return _0x26aab6 - _0x923360;
          },
          "kLzCQ": function (_0x385bd1) {
            return _0x385bd1();
          },
          "GJOAG": function (_0x495e62, _0x447de9) {
            return _0x495e62 !== _0x447de9;
          },
          "GAZhn": "waHsP",
          "ruHGV": function (_0x10d0ad, _0x47a64c) {
            return _0x10d0ad - _0x47a64c;
          },
          "yuKyq": function (_0x25474f, _0x499112) {
            return _0x25474f + _0x499112;
          },
          "UIFCP": function (_0x2d42cc, _0x162be4) {
            return _0x2d42cc * _0x162be4;
          },
          "yFTDR": function (_0x5a6858, _0x70ec2) {
            return _0x5a6858 * _0x70ec2;
          },
          "SFAPq": function (_0x5ba050, _0x247cc9) {
            return _0x5ba050 === _0x247cc9;
          },
          "IcZBl": "ckvXo",
          "BUDCL": function (_0x30c861, _0x5da8c4) {
            return _0x30c861 + _0x5da8c4;
          },
          "PLTVB": "lastUpdated",
          "QfgHL": "value",
          "QBmeL": "VZOnu",
          "pneAy": "timeToLive",
          "ZWaZx": "get",
          "EfHBR": function (_0x4ae6b3, _0x514d4e) {
            return _0x4ae6b3 !== _0x514d4e;
          },
          "tLqwy": "yKEzt",
          "zwwNy": function (_0x4c38d7, _0x338abd) {
            return _0x4c38d7(_0x338abd);
          },
          "GorBw": function (_0x2609c2, _0xb99be1) {
            return _0x2609c2 + _0xb99be1;
          },
          "Iacpe": "cpx_interact",
          "PUeDg": function (_0x11c6c6, _0x44ad85) {
            return _0x11c6c6 === _0x44ad85;
          },
          "gEZvh": function (_0x35d1b5, _0x4a01a2) {
            return _0x35d1b5 === _0x4a01a2;
          },
          "MGiUZ": function (_0x4c254d, _0x283177) {
            return _0x4c254d + _0x283177;
          },
          "rpPfk": "-enter",
          "DGqXK": function (_0x6304ea, _0x4ec972) {
            return _0x6304ea === _0x4ec972;
          },
          "UHuWc": function (_0x2e19f0, _0x1e9fd4) {
            return _0x2e19f0 === _0x1e9fd4;
          },
          "HgxGA": "sIiYT",
          "gdrvC": "resolve",
          "XAcMZ": "timeout",
          "Evmys": function (_0x33309b, _0x4612ee, _0x29047b, _0x397d50) {
            return _0x33309b(_0x4612ee, _0x29047b, _0x397d50);
          },
          "gWZmW": function (_0x47fbee, _0x5bf238) {
            return _0x47fbee !== _0x5bf238;
          },
          "ygBWH": "kwsIm",
          "pzMCL": "ZulcE",
          "FSVEg": function (_0xaf972e, _0x226e6e) {
            return _0xaf972e === _0x226e6e;
          },
          "MfQIP": function (_0x12175c, _0xcb96fc) {
            return _0x12175c + _0xcb96fc;
          },
          "lzeMu": "-exit",
          "KovHW": function (_0x8f81c1, _0x564968) {
            return _0x8f81c1 === _0x564968;
          },
          "qrkdD": "NcGhm",
          "sppFk": function (_0x4707c2, _0xdcdf91) {
            return _0x4707c2 + _0xdcdf91;
          },
          "qsDwJ": "VebDF",
          "WPuYP": "data",
          "CQsbZ": "cpx_polyzone",
          "WEBeQ": function (_0x12bb04, _0x2d085f) {
            return _0x12bb04 !== _0x2d085f;
          },
          "KGFNi": "edasq",
          "RxTnH": "Failed to encode payload",
          "vZnnf": function (_0x191773, _0x16eb37) {
            return _0x191773 > _0x16eb37;
          },
          "HJxDK": function (_0x1f9bb9) {
            return _0x1f9bb9();
          },
          "XNXXw": function (_0x12a8f6, _0xae3d41) {
            return _0x12a8f6(_0xae3d41);
          },
          "tzZpH": function (_0x3daadb, _0x571194) {
            return _0x3daadb !== _0x571194;
          },
          "EgFnX": "yhisW",
          "sOdIU": function (_0x196408, _0xb7819f) {
            return _0x196408 === _0xb7819f;
          },
          "QAQNB": "solvA",
          "BqUYU": "Failed to decode payload",
          "zOxRj": function (_0x2f88fe, _0x4f0ca9, _0x1fa241) {
            return _0x2f88fe(_0x4f0ca9, _0x1fa241);
          },
          "PhzpQ": function (_0xd1d9df, _0x3cb43e) {
            return _0xd1d9df === _0x3cb43e;
          },
          "fdGTv": "aQqRW",
          "sIYkH": "ihLHT",
          "zDhxM": function (_0x32708b, _0xfa4da6) {
            return _0x32708b(_0xfa4da6);
          },
          "NfKZp": function (_0x5e795c, _0x48cca5) {
            return _0x5e795c(_0x48cca5);
          },
          "AsZHT": "waitForCondition",
          "cBIZp": "object",
          "DiObs": "return this",
          "NAWkJ": "kFSsN",
          "VhMjs": "PPghJ",
          "FjBNT": function (_0x7d61de, _0x464c5b) {
            return _0x7d61de(_0x464c5b);
          },
          "CpJbB": function (_0x41b36f, _0x156ce3) {
            return _0x41b36f(_0x156ce3);
          },
          "uhblA": "LZeVS",
          "ZQvgT": function (_0x2591c7, _0x1e1a7c) {
            return _0x2591c7(_0x1e1a7c);
          },
          "XwowB": function (_0xc7050b, _0xb3d928, _0x44ffc7) {
            return _0xc7050b(_0xb3d928, _0x44ffc7);
          },
          "KPstk": function (_0x2a912b, _0x321536) {
            return _0x2a912b === _0x321536;
          },
          "hWaIe": function (_0x434f98, _0x5187cc) {
            return _0x434f98(_0x5187cc);
          },
          "VDlyI": function (_0x107a70, _0x349776) {
            return _0x107a70(_0x349776);
          },
          "ltwVg": function (_0x4949d9, _0x3f352b) {
            return _0x4949d9 + _0x3f352b;
          },
          "bADlG": "bLjfA",
          "fhnJR": "decodePayload",
          "TEQNC": "[RPC] Received malformed packet:",
          "cKMcR": function (_0x407e4b, _0x5236ff) {
            return _0x407e4b === _0x5236ff;
          },
          "LmPuG": "WJfzW",
          "Xlzdy": function (_0x3be488, ..._0x2dfc62) {
            return _0x3be488(..._0x2dfc62);
          },
          "wKvRm": "type",
          "tiJmd": "emitNet",
          "LDBwt": function (_0x455bbc, _0x23ec82) {
            return _0x455bbc + _0x23ec82;
          },
          "WTtQJ": "__cpx_res:",
          "rlKke": "origin",
          "ukLpi": "emit",
          "fIXAj": function (_0xeb533f, _0x21379a) {
            return _0xeb533f + _0x21379a;
          },
          "EnWgF": function (_0x15650b, _0xcb5047) {
            return _0x15650b < _0xcb5047;
          },
          "HwXxx": "length",
          "iHMkG": function (_0x2cbb87, _0x44b072, _0x4a916e, _0x2e2d0f) {
            return _0x2cbb87(_0x44b072, _0x4a916e, _0x2e2d0f);
          },
          "iqAwE": function (_0x51f5cc, _0x27f786, _0x3c1cdf, _0x55becd, _0xc8e19b) {
            return _0x51f5cc(_0x27f786, _0x3c1cdf, _0x55becd, _0xc8e19b);
          },
          "DugPw": "Invalid Blip Type",
          "VIpcj": "SkIWO",
          "wnMnf": "sUlql",
          "lAWUL": "cpx_taskbar",
          "YzkgW": function (_0x12bc66, _0x553d70) {
            return _0x12bc66 === _0x553d70;
          },
          "SIIfY": function (_0x319609, _0xd1aa7d) {
            return _0x319609 === _0xd1aa7d;
          },
          "UzOwS": "entity",
          "Ybcmp": "cpx_phone",
          "jNEwc": "mesxQ"
        };
        var _0x15f35d;
        _0x15f35d = {
          "value": true
        };
        console.log("[CPX] Loaded!");
        const _0x3a3729 = GetCurrentResourceName();
        const _0x1c5726 = new Map();
        const _0x39d140 = new Set();
        const _0x3f6b4d = new Map();
        let _0x226a8b = new Date().getTime();
        const _0xcb7fd9 = (_0x10483c, ..._0x1188e5) => {
          switch (_0x10483c) {
            case "coord":
              {
                const [_0x237755, _0x364721, _0x3f7860] = _0x1188e5;
                return AddBlipForCoord(_0x237755, _0x364721, _0x3f7860);
              }
            case "area":
              {
                const [_0x4ae402, _0x4a686c, _0x4997cd, _0x220d9b, _0x2b003e] = _0x1188e5;
                return AddBlipForArea(_0x4ae402, _0x4a686c, _0x4997cd, _0x220d9b, _0x2b003e);
              }
            case "radius":
              {
                const [_0x1f898b, _0x5f47c5, _0x258595, _0x54bc6e] = _0x1188e5;
                return AddBlipForRadius(_0x1f898b, _0x5f47c5, _0x258595, _0x54bc6e);
              }
            case "pickup":
              {
                const [_0x282603] = _0x1188e5;
                return AddBlipForPickup(_0x282603);
              }
            case "entity":
              {
                const [_0x54a6d1] = _0x1188e5;
                return AddBlipForEntity(_0x54a6d1);
              }
            default:
              {
                console.error(new Error("Invalid Blip Type"));
                return 0;
              }
          }
        };
        const _0x4d7ef9 = (_0x4fce0a, _0x38dea5, _0x5c563a, _0x5185ea, _0x3a65bb, _0x50dbe0, _0x1801b3, _0x50ee27) => {
          if (typeof _0x5c563a === "number") {
            SetBlipSprite(_0x4fce0a, _0x5c563a);
          }
          if (typeof _0x5185ea === "number") {
            SetBlipColour(_0x4fce0a, _0x5185ea);
          }
          if (typeof _0x3a65bb === "number") {
            SetBlipAlpha(_0x4fce0a, _0x3a65bb);
          }
          if (typeof _0x50dbe0 === "number") {
            SetBlipScale(_0x4fce0a, _0x50dbe0);
          }
          if (typeof _0x1801b3 === "boolean") {
            SetBlipRoute(_0x4fce0a, _0x1801b3);
          }
          if (typeof _0x50ee27 === "boolean") {
            SetBlipAsShortRange(_0x4fce0a, _0x50ee27);
          }
          if (typeof _0x38dea5 === "string") {
            BeginTextCommandSetBlipName("STRING");
            AddTextComponentString(_0x38dea5);
            EndTextCommandSetBlipName(_0x4fce0a);
          }
        };
        let _0x340c9c = {
          createBlip: _0xcb7fd9,
          applyBlipSettings: _0x4d7ef9
        };
        const _0x4c18ab = (_0x52d6f6, _0x324c39, _0x1ec3b6) => {
          return _0x324c39[0] + (_0x1ec3b6 - _0x52d6f6[0]) * (_0x324c39[1] - _0x324c39[0]) / (_0x52d6f6[1] - _0x52d6f6[0]);
        };
        const _0x28714e = ([_0x39378f, _0x32310e, _0x55b741], [_0x23c222, _0x3feb97, _0x6afdeb]) => {
          const [_0x577da6, _0xda21b8, _0x1a70c0] = [_0x39378f - _0x23c222, _0x32310e - _0x3feb97, _0x55b741 - _0x6afdeb];
          return Math.sqrt(_0x577da6 * _0x577da6 + _0xda21b8 * _0xda21b8 + _0x1a70c0 * _0x1a70c0);
        };
        const _0x1d8a62 = (_0x5e8248, _0x5061cb) => {
          return Math.floor(_0x5061cb ? Math.random() * (_0x5061cb - _0x5e8248) + _0x5e8248 : Math.random() * _0x5e8248);
        };
        let _0x3bc379 = {
          getMapRange: _0x4c18ab,
          getDistance: _0x28714e,
          getRandomNumber: _0x1d8a62
        };
        function _0x35c29(_0x25dc87, _0x2bc9f1) {
          const _0x407c33 = {
            "jMUrB": "MXorD",
            "XHcpF": function (_0x3f4c56, _0x10f30b, ..._0x5934be) {
              return _0x53cddd.rmkqQ(_0x3f4c56, _0x10f30b, ..._0x5934be);
            },
            "UnUOg": "ev-interact",
            "tFcaM": function (_0xf03aea, _0x5b263a) {
              return _0xf03aea === _0x5b263a;
            },
            "QgfAx": "BxKzg",
            "JKkHJ": "2|0|6|5|4|3|1",
            "ioeDv": function (_0x1261f0, _0x4753f1) {
              return _0x1261f0 === _0x4753f1;
            },
            "yTtyM": function (_0x50e63c, _0x5139bc, _0x59050e) {
              return _0x53cddd.rmkqQ(_0x50e63c, _0x5139bc, _0x59050e);
            },
            "ntdbL": "string",
            "UTptt": function (_0x31abf9, _0x2ed8ce) {
              return _0x31abf9(_0x2ed8ce);
            },
            "qfQQT": "STRING",
            "kbPHb": function (_0x2659f4, _0x3d3b20) {
              return _0x2659f4(_0x3d3b20);
            },
            "hvzgZ": "number",
            "MmFVH": function (_0x135647, _0x4a802f) {
              return _0x135647 === _0x4a802f;
            },
            "rYqYx": "boolean",
            "KSNdt": function (_0x4ea873, _0x2a8316, _0x419e93) {
              return _0x4ea873(_0x2a8316, _0x419e93);
            },
            "ekbaD": function (_0x3f108f, _0x351538) {
              return _0x3f108f === _0x351538;
            },
            "Pdzug": function (_0x152b50, _0x3d4ecd) {
              return _0x152b50 === _0x3d4ecd;
            }
          };
          const _0x51dde3 = _0x3cb617((_0x710da9, _0x136da, ..._0x215b34) => {
            return _0x407c33.XHcpF(_0x25dc87, _0x710da9, ..._0x215b34);
          }, _0x2bc9f1);
          var _0x2f7059 = {
            get: function (..._0x13375a) {
              return _0x51dde3.get("_", ..._0x13375a);
            },
            reset: function () {
              _0x51dde3.reset("_");
            }
          };
          return _0x2f7059;
        }
        function _0x3cb617(_0x26e462, _0x41c67e) {
          const _0x7a35d1 = _0x41c67e.timeToLive || 60000;
          const _0x421b81 = {};
          async function _0x3863a5(_0x56a4c7, ..._0x1a9613) {
            let _0x508545 = _0x421b81[_0x56a4c7];
            if (!_0x508545) {
              var _0x26d123 = {
                value: null,
                lastUpdated: 0
              };
              _0x508545 = _0x26d123;
              _0x421b81[_0x56a4c7] = _0x508545;
            }
            const _0x5bf56a = Date.now();
            if (_0x508545.lastUpdated === 0 || _0x5bf56a - _0x508545.lastUpdated > _0x7a35d1) {
              const [_0x2acec4, _0x1af877] = await _0x26e462(_0x508545, _0x56a4c7, ..._0x1a9613);
              if (_0x2acec4) {
                _0x508545.lastUpdated = _0x5bf56a;
                _0x508545.value = _0x1af877;
              }
              return _0x1af877;
            }
            return await new Promise(_0x202b9e => setTimeout(() => _0x202b9e(_0x508545.value), 0));
          }
          var _0x56e73c = {
            get: async function (_0x1cc29c, ..._0x458ec6) {
              return await _0x3863a5(_0x1cc29c, ..._0x458ec6);
            },
            reset: function (_0x3cba4c) {
              var _0x8c040d = _0x421b81[_0x3cba4c];
              if (_0x8c040d) {
                _0x8c040d.lastUpdated = 0;
              }
            }
          };
          return _0x56e73c;
        }
        function _0x493ae5(_0x37e443, _0x2b83ad) {
          return new Promise(_0x1c6ba8 => {
            const _0x1e0013 = Date.now();
            const _0x96b720 = setTick(() => {
              const _0x21fb6f = Date.now() - _0x1e0013 > _0x2b83ad;
              if (_0x37e443() || _0x21fb6f) {
                clearTick(_0x96b720);
                return _0x1c6ba8(_0x21fb6f);
              }
            });
          });
        }
        let _0x187122 = {
          cache: _0x35c29,
          cacheableMap: _0x3cb617,
          waitForCondition: _0x493ae5
        };
        const _0x4a8617 = Object.assign(_0x187122, _0x3bc379);
        on("ev-polyzone:enter", (_0x4ec29d, _0x2eea7e) => {
          _0x39d140.add(_0x4ec29d);
          if (_0x2eea7e === null || _0x2eea7e === undefined ? undefined : _0x2eea7e.id) {
            _0x39d140.add(_0x4ec29d + "-" + _0x2eea7e.id);
          }
          const _0x374fff = _0x3f6b4d.get(_0x4ec29d + "-enter");
          if (_0x374fff === undefined) {
            return;
          }
          for (const _0x44f9e5 of _0x374fff) {
            try {
              _0x44f9e5(_0x2eea7e);
            } catch (_0x209c49) {
              console.log(_0x209c49);
            }
          }
        });
        on("ev-polyzone:exit", (_0x33632b, _0x102e5f) => {
          _0x39d140["delete"](_0x33632b);
          if (_0x102e5f === null || _0x102e5f === undefined ? undefined : _0x102e5f.id) {
            _0x39d140["delete"](_0x33632b + "-" + _0x102e5f.id);
          }
          const _0x32bb83 = _0x3f6b4d.get(_0x33632b + "-exit");
          if (_0x32bb83 === undefined) {
            return;
          }
          for (const _0x278898 of _0x32bb83) {
            try {
              _0x278898(_0x102e5f);
            } catch (_0x35e5b7) {
              console.log(_0x35e5b7);
            }
          }
        });
        const _0x1440ac = (_0x394bd2, _0x15745a) => {
          return _0x39d140.has(_0x15745a ? _0x394bd2 + "-" + _0x15745a : _0x394bd2);
        };
        const _0x4019ab = (_0xb8b5b2, _0x199cc9) => {
          var _0x58b1ff;
          const _0x2a3639 = _0xb8b5b2 + "-enter";
          const _0x113611 = (_0x58b1ff = _0x3f6b4d.get(_0x2a3639)) !== null && _0x58b1ff !== undefined ? _0x58b1ff : [];
          if (!_0x3f6b4d.has(_0x2a3639)) {
            _0x3f6b4d.set(_0x2a3639, _0x113611);
          }
          _0x113611.push(_0x199cc9);
        };
        const _0x47e217 = (_0x4547eb, _0xb24991) => {
          var _0xd48437;
          const _0x5c7d4c = _0x4547eb + "-exit";
          const _0x4a5452 = (_0xd48437 = _0x3f6b4d.get(_0x5c7d4c)) !== null && _0xd48437 !== undefined ? _0xd48437 : [];
          if (!_0x3f6b4d.has(_0x5c7d4c)) {
            _0x3f6b4d.set(_0x5c7d4c, _0x4a5452);
          }
          _0x4a5452.push(_0xb24991);
        };
        const _0x5b5a0e = (id, zone, vectors, length, width, options, data = {}) => {
          const opt = { ...options, data: data || {} };
        
          opt.data['id'] = id;
        
          global.exports["ev-polyzone"].AddBoxZone(zone, vectors, length, width, opt);
        }        
        const _0x27796b = (id, zone, vectors, length, width, options, data = {}) => {
          const opt = { ...options, data };
      
          opt.data['id'] = id;
      
          global.exports["ev-polytarget"].AddBoxZone(zone, vectors, length, width, opt);
      }
      
        let _0x39a214 = {
          isActive: _0x1440ac,
          onEnter: _0x4019ab,
          onExit: _0x47e217,
          addBoxZone: _0x5b5a0e,
          addBoxTarget: _0x27796b
        };
        const _0x27a69d = _0x242878 => {
          try {
            return JSON.stringify(_0x242878);
          } catch (_0x56cfc9) {
            console.error("Failed to encode payload");
          }
        };
        const _0x54160e = _0x179ba8 => {
          try {
            return JSON.parse(_0x179ba8);
          } catch (_0x4f0ecb) {
            console.error("Failed to decode payload");
          }
        };
        let _0x22ce9b = {
          encodePayload: _0x27a69d,
          decodePayload: _0x54160e
        };
        const _0x2aa4b3 = (_0x2752e1, _0x3df352) => {
          return on(_0x2752e1, _0x3df352);
        };
        const _0x5386e6 = (_0x2d01ad, _0x27a47a) => {
          return onNet(_0x2d01ad, _0x27a47a);
        };
        const _0x312068 = (_0x15ccc3, _0x77c62f) => {
          removeEventListener(_0x15ccc3, _0x77c62f);
        };
        const _0x3781dc = (_0x41efec, ..._0x1d1379) => {
          emit(_0x41efec, ..._0x1d1379);
        };
        const _0x2025d0 = (_0x617114, ..._0x304dc0) => {
          const _0x48e62f = msgpack_pack(_0x304dc0);
          if (_0x48e62f.length < 16000) {
            TriggerServerEventInternal(_0x617114, _0x48e62f, _0x48e62f.length);
          } else {
            TriggerLatentServerEventInternal(_0x617114, _0x48e62f, _0x48e62f.length, 128000);
          }
        };
        let _0x21a3e2 = {
          on: _0x2aa4b3,
          onNet: _0x5386e6,
          emit: _0x3781dc,
          emitNet: _0x2025d0,
          remove: _0x312068
        };
        const _0x268c32 = async (model) => {
          const hash = typeof model === "number" ? model : GetHashKey(model);
          if (HasModelLoaded(hash)) return true;
      
          RequestModel(hash);
      
          const hasLoaded = await _0x4a8617.waitForCondition(() => HasModelLoaded(hash), 30000);
      
          return !hasLoaded;
      }
        const _0x382022 = async _0x4ccf65 => {
          if (HasAnimDictLoaded(_0x4ccf65)) {
            return true;
          }
          RequestAnimDict(_0x4ccf65);
          const _0x3ae3e1 = await _0x4a8617.waitForCondition(() => HasAnimDictLoaded(_0x4ccf65), 30000);
          return !_0x3ae3e1;
        };
        const _0x5cdb19 = async _0x316a0d => {
          if (HasClipSetLoaded(_0x316a0d)) {
            return true;
          }
          RequestClipSet(_0x316a0d);
          const _0x4e269a = await _0x4a8617.waitForCondition(() => HasClipSetLoaded(_0x316a0d), 30000);
          return !_0x4e269a;
        };
        const _0x45927a = async _0x2959f3 => {
          if (HasStreamedTextureDictLoaded(_0x2959f3)) {
            return true;
          }
          RequestStreamedTextureDict(_0x2959f3, true);
          const _0x4f4809 = await _0x4a8617.waitForCondition(() => HasStreamedTextureDictLoaded(_0x2959f3), 30000);
          return !_0x4f4809;
        };
        const _0x20a2cb = async (_0x193985, _0x3985a1, _0x30ba0d) => {
          const _0x44b0ee = typeof _0x193985 === "number" ? _0x193985 : GetHashKey(_0x193985);
          if (HasWeaponAssetLoaded(_0x44b0ee)) {
            return true;
          }
          RequestWeaponAsset(_0x44b0ee, _0x3985a1, _0x30ba0d);
          const _0x4d932b = await _0x4a8617.waitForCondition(() => HasWeaponAssetLoaded(_0x44b0ee), 30000);
          return !_0x4d932b;
        };
        const _0x3a0fd8 = async _0x451263 => {
          if (HasNamedPtfxAssetLoaded(_0x451263)) {
            return true;
          }
          RequestNamedPtfxAsset(_0x451263);
          const _0x154e2a = await _0x4a8617.waitForCondition(() => HasNamedPtfxAssetLoaded(_0x451263), 30000);
          return !_0x154e2a;
        };
        let _0xb3dd3c = {
          loadModel: _0x268c32,
          loadTexture: _0x45927a,
          loadAnim: _0x382022,
          loadClipSet: _0x5cdb19,
          loadWeaponAsset: _0x20a2cb,
          loadNamedPtfxAsset: _0x3a0fd8
        };
        const _0x90c618 = (_0x38aeba, _0x5332b9) => {
          _0x21a3e2.onNet("__cpx_req:" + _0x38aeba, async (_0x3debe2, _0xcde153) => {
            let _0x259275;
            let _0x2f4986;
            const _0x3c66a6 = _0x22ce9b.decodePayload(_0x3debe2);
            if (_0x3c66a6 === undefined) {
              return console.log("[RPC] Received malformed packet:", _0x3debe2);
            }
            try {
              _0x259275 = await _0x3f516e.Xlzdy(_0x5332b9, ..._0xcde153);
              _0x2f4986 = true;
            } catch (_0x20c742) {
              _0x259275 = _0x20c742;
              _0x2f4986 = false;
            }
            if (_0x3c66a6.type === "remote") {
              _0x21a3e2.emitNet("__cpx_res:" + _0x3c66a6.origin, _0x3c66a6.id, [_0x2f4986, _0x259275]);
            } else if (_0x3c66a6.type === "local") {
              _0x21a3e2.emit("__cpx_res:" + _0x3c66a6.origin, _0x3c66a6.id, [_0x2f4986, _0x259275]);
            }
          });
        };
        const _0x386d3a = (_0x557402, ..._0x2c6686) => {
          console.log("[RPC] Executing procedure:", _0x557402, _0x2c6686);
          const _0x4cb5d1 = GetPlayerServerId(PlayerId());
          var _0x280715 = {
            id: ++_0x226a8b,
            type: "remote",
            origin: _0x3a3729,
            src: _0x4cb5d1
          };
          const _0x4df86e = new Promise((_0x5d39e7, _0x5c2c14) => {
            const _0x5896cc = +setTimeout(() => _0x5c2c14(new Error("Remote call timed out | " + _0x557402)), 60000);
            var _0x34144b = {
              resolve: _0x5d39e7,
              reject: _0x5c2c14,
              "timeout": _0x5896cc
            };
            _0x1c5726.set(_0x280715.id, _0x34144b);
          });
          _0x21a3e2.emitNet("__cpx_req:" + _0x557402, _0x22ce9b.encodePayload(_0x280715), _0x2c6686);
          _0x4df86e["finally"](() => _0x1c5726["delete"](_0x280715.id));
          return _0x4df86e;
        };
        _0x21a3e2.onNet("__cpx_res:" + _0x3a3729, (_0x194c82, _0xca1786) => {
          const _0x502fb0 = _0x1c5726.get(_0x194c82);
          if (_0x502fb0 === undefined) {
            return;
          }
          clearTimeout(_0x502fb0.timeout);
          const [_0x43fd0b, _0x9f0cff] = _0xca1786;
          if (_0x43fd0b) {
            _0x502fb0.resolve(_0x9f0cff);
          } else {
            _0x502fb0.reject(new Error(_0x9f0cff));
          }
        });
        let _0x3dc8fb = {
          register: _0x90c618,
          execute: _0x386d3a
        };
        const _0x3cf216 = (_0x11a163, _0x5f34b2, _0xd4218e) => {
          _0x275f08.g.exports["ev-interact"].AddPeekEntryByModel(_0x11a163, _0x5f34b2, _0xd4218e);
        };
        const _0x5b630b = (_0xe4c28e, _0x54d120, _0x3541c9) => {
          _0x275f08.g.exports["ev-interact"].AddPeekEntryByPolyTarget(_0xe4c28e, _0x54d120, _0x3541c9);
        };
        const _0x33ce29 = (_0x2d490e, _0x1a6d16, _0x2aab6c) => {
          _0x275f08.g.exports["ev-interact"].AddPeekEntryByFlag(_0x2d490e, _0x1a6d16, _0x2aab6c);
        };
        const _0xb0d4e4 = (_0x5e9fb2, _0xfbb0b3, _0x3731b2 = false, _0x934359 = null) => {
          return new Promise(_0x1d3534 => {
            _0x275f08.g.exports["ev-taskbar"].taskBar(_0x5e9fb2, _0xfbb0b3, _0x3731b2, true, null, false, _0x1d3534, _0x934359 === null || _0x934359 === undefined ? undefined : _0x934359.distance, _0x934359 === null || _0x934359 === undefined ? undefined : _0x934359.entity);
          });
        };
        const _0x33c940 = (_0x40755a, _0x13c32b, _0x4abf51) => {
          return new Promise(_0x123dd6 => {
            _0x275f08.g.exports["ev-phone"].DoPhoneConfirmation(_0x40755a, _0x13c32b, _0x4abf51, _0x123dd6);
          });
        };
        const _0x1b3545 = (_0x56d3f6, _0x596be5, _0x38b35d, _0x54ab9 = true) => {
          _0x275f08.g.exports["ev-phone"].DoPhoneNotification(_0x56d3f6, _0x596be5, _0x38b35d, _0x54ab9);
        };
        let _0x4dc139 = {
          addPeekEntryByModel: _0x3cf216,
          addPeekEntryByTarget: _0x5b630b,
          addPeekEntryByFlag: _0x33ce29,
          taskBar: _0xb0d4e4,
          phoneConfirmation: _0x33c940,
          phoneNotification: _0x1b3545
        };
        let _0x55b19a = {
          Events: _0x21a3e2,
          Procedures: _0x3dc8fb,
          Zones: _0x39a214,
          Streaming: _0xb3dd3c,
          Utils: _0x4a8617,
          Interface: _0x4dc139,
          Hud: _0x340c9c
        };
        _0x275f08.g.CPX = _0x55b19a;
        setImmediate(() => {
          _0x275f08.g.exports("GetLibrary", () => {
            return _0x55b19a;
          });
        });
      }
    };
    var _0x58d4bd = {};
    !function () {
      _0x58d4bd.g = function () {
        if (typeof globalThis === "object") {
          return globalThis;
        }
        try {
          return this || new Function("return this")();
        } catch (_0x308f50) {
          if (typeof window === "object") {
            return window;
          }
        }
      }();
    }();
    var _0x4bae2c = {};
    _0x3cf6c0[50](0, _0x4bae2c, _0x58d4bd);
  })();
!function () {
    'use strict';
  
    const _0x46fa83 = {
      "mAtvZ": "Failed to encode payload",
      "ojyZo": function (_0x2ea458, _0x35437c) {
        return _0x2ea458 == _0x35437c;
      },
      "gxrDE": "WNqzc",
      "OsWmZ": "return this",
      "wkPju": function (_0x7d401f, _0x58c23f) {
        return _0x7d401f == _0x58c23f;
      },
      "mabzb": "object",
      "INMkH": "Failed to decode payload",
      "mlKyt": "bUYIm",
      "ZUMkA": function (_0x2dd1e7, _0x5829d9) {
        return _0x2dd1e7 - _0x5829d9;
      },
      "hbPux": function (_0x1f13b8, _0x42875e) {
        return _0x1f13b8 - _0x42875e;
      },
      "FnPvk": function (_0x40143a, _0x1b991a) {
        return _0x40143a + _0x1b991a;
      },
      "YdOwO": function (_0x3f7e89, _0x3df26e) {
        return _0x3f7e89 + _0x3df26e;
      },
      "VSPLg": function (_0x2dd44b, _0x198b43) {
        return _0x2dd44b * _0x198b43;
      },
      "SWzYd": function (_0xc5ed7c, _0x1c3ac4) {
        return _0xc5ed7c * _0x1c3ac4;
      },
      "mLmff": function (_0xf3f8fd, _0x4bba6b) {
        return _0xf3f8fd !== _0x4bba6b;
      },
      "bqMwd": "vxhvL",
      "CVdgi": function (_0x42174e, _0x2435b7) {
        return _0x42174e === _0x2435b7;
      },
      "TUOPK": function (_0x1efc0c, _0x278e36, _0x1d745f, ..._0x1b236c) {
        return _0x1efc0c(_0x278e36, _0x1d745f, ..._0x1b236c);
      },
      "oclux": function (_0x2ab5c6, _0x48c735) {
        return _0x2ab5c6 !== _0x48c735;
      },
      "mLOkL": "pRQfK",
      "kbPbJ": "HtRhZ",
      "AKSNz": function (_0x127c05, _0x11230c) {
        return _0x127c05 === _0x11230c;
      },
      "Ehwha": "GrYOF",
      "NswOH": function (_0x5ba625, _0x809352, _0x2884f3) {
        return _0x5ba625(_0x809352, _0x2884f3);
      },
      "gTfLD": function (_0x221c6f, _0xd2ea50) {
        return _0x221c6f === _0xd2ea50;
      },
      "cYYvR": "IeOVr",
      "hUlQZ": "OdAsB",
      "yyrnX": function (_0x38a523, _0x340230) {
        return _0x38a523 - _0x340230;
      },
      "dHdHa": function (_0x32f30a) {
        return _0x32f30a();
      },
      "XsDZt": function (_0x5b5ce9, _0xd3714e) {
        return _0x5b5ce9(_0xd3714e);
      },
      "lEiVg": function (_0x5bf1f2, _0x98a4a8) {
        return _0x5bf1f2(_0x98a4a8);
      },
      "umelV": function (_0x787401, _0x5cba97) {
        return _0x787401 > _0x5cba97;
      },
      "CtLau": function (_0x1b83cd, _0x36fd3d) {
        return _0x1b83cd === _0x36fd3d;
      },
      "ttyrh": "yVqmD",
      "yaxoo": "hsYaE",
      "NKKIN": function (_0x114a43, _0xd0b78c) {
        return _0x114a43 === _0xd0b78c;
      },
      "wtofS": "YeiyH",
      "JWeNF": function (_0x5e00ec, _0xe351cc, _0x3cd1eb) {
        return _0x5e00ec(_0xe351cc, _0x3cd1eb);
      },
      "tqZWb": "pQaMk",
      "oHasz": function (_0x2a5f5c, _0x47b808) {
        return _0x2a5f5c === _0x47b808;
      },
      "FNsfq": "DeaJn",
      "hzpek": function (_0x139e57, _0x198f72) {
        return _0x139e57 < _0x198f72;
      },
      "YgVzk": function (_0x495d3d, _0x4126cc, _0x52490a, _0x2805df, _0x1f6779) {
        return _0x495d3d(_0x4126cc, _0x52490a, _0x2805df, _0x1f6779);
      },
      "jBbGw": function (_0x5e3099, _0x212041, _0x2f5159, _0x2db33c, _0x3fc0ce, _0x29f0b9) {
        return _0x5e3099(_0x212041, _0x2f5159, _0x2db33c, _0x3fc0ce, _0x29f0b9);
      },
      "snwWV": function (_0xb72f93) {
        return _0xb72f93();
      },
      "fatcX": "blxNq",
      "urjYx": "HQCYY",
      "daLru": function (_0x1b712c, _0x563564) {
        return _0x1b712c(_0x563564);
      },
      "vbHWG": function (_0x4b1302, _0x2f11c3, _0x40b3c1) {
        return _0x4b1302(_0x2f11c3, _0x40b3c1);
      },
      "YuBFt": "__cpx_req:",
      "WcHZp": "Received request: ",
      "uuIyE": "[RPC] Received malformed packet:",
      "aojla": "remote",
      "INPHu": function (_0x386a80, _0x213eda) {
        return _0x386a80 + _0x213eda;
      },
      "jZeYF": "__cpx_res:",
      "RfYDy": "local",
      "nAazh": function (_0x2bb4f6, _0x4e33df) {
        return _0x2bb4f6 + _0x4e33df;
      },
      "PnejF": "UOfQC",
      "WvFBQ": "OYDnD",
      "CwojK": function (_0x3051b6, _0x4158b7) {
        return _0x3051b6 + _0x4158b7;
      },
      "HvplE": function (_0x5c8d4a, _0x5c41fc) {
        return _0x5c8d4a * _0x5c41fc;
      },
      "kMboz": function (_0x241c38, _0x36e9fd) {
        return _0x241c38 * _0x36e9fd;
      },
      "sGzCn": function (_0x35bd18, _0x5c06ca) {
        return _0x35bd18(_0x5c06ca);
      },
      "JlUyJ": function (_0x43cb76, _0x30e6c9) {
        return _0x43cb76 === _0x30e6c9;
      },
      "gCOGH": "IqpEu",
      "UGhTY": function (_0x19ac50, _0x71893a) {
        return _0x19ac50 + _0x71893a;
      },
      "QDUcc": function (_0x218bee, _0x405e43, _0x3b8c10) {
        return _0x218bee(_0x405e43, _0x3b8c10);
      },
      "BvLfp": "qNaxA",
      "jaHsC": "mfaCy",
      "BpdpX": "[CPX] Loaded!"
    };
    var _0x2fd61a = {
      g: function () {
        if ("object" == typeof globalThis) {
          return globalThis;
        }
        try {
          return this || new Function("return this")();
        } catch (_0x2e3bbf) {
          if ("object" == typeof window) {
            return window;
          }
        }
      }()
    };
    console.log("[CPX] Loaded!");
    const _0x56af7f = GetCurrentResourceName();
    const _0x282180 = new Map();
    let _0x25e784 = new Date().getTime();
    const _0x4d9ae6 = {
      "getMapRange": (_0x6e5025, _0x223fbc, _0x14444d) => _0x223fbc[0] + (_0x14444d - _0x6e5025[0]) * (_0x223fbc[1] - _0x223fbc[0]) / (_0x6e5025[1] - _0x6e5025[0]),
      "getDistance": ([_0x4dec3b, _0x464d77, _0x563f48], [_0x1cc062, _0x5d33c1, _0x6fe9e4]) => {
        const [_0x5e8457, _0x2b4463, _0x14ade8] = [_0x4dec3b - _0x1cc062, _0x464d77 - _0x5d33c1, _0x563f48 - _0x6fe9e4];
        return Math.sqrt(_0x5e8457 * _0x5e8457 + _0x2b4463 * _0x2b4463 + _0x14ade8 * _0x14ade8);
      },
      "getRandomNumber": (_0x43427e, _0x2c6088) => Math.floor(_0x2c6088 ? Math.random() * (_0x2c6088 - _0x43427e) + _0x43427e : Math.random() * _0x43427e)
    };
    function _0x26b991(_0x11efd2, _0xe10eef) {
      const _0x296cc3 = {
        "koGct": function (_0x421535, _0x52e09f) {
          return _0x421535 === _0x52e09f;
        },
        "EtzQa": function (_0x3c2991, _0x4d6186) {
          return _0x3c2991 - _0x4d6186;
        },
        "jPOim": function (_0x521fb5, _0x238c92, _0x25d202, ..._0x19ef77) {
          return _0x46fa83.TUOPK(_0x521fb5, _0x238c92, _0x25d202, ..._0x19ef77);
        }
      };
      const _0x1b3105 = _0xe10eef.timeToLive || 60000;
      const _0x38bda3 = {};
      var _0xa56f2 = {
        "get": async function (_0x23f561, ..._0x3ddbed) {
          return await async function (_0x2bb5fd, ..._0x4ffbc9) {
            let _0x2ccffb = _0x38bda3[_0x2bb5fd];
            if (!_0x2ccffb) {
              _0x2ccffb = {
                "value": null,
                "lastUpdated": 0x0
              };
              _0x38bda3[_0x2bb5fd] = _0x2ccffb;
            }
            const _0x57f4b2 = Date.now();
            if (0 === _0x2ccffb.lastUpdated || _0x57f4b2 - _0x2ccffb.lastUpdated > _0x1b3105) {
              const [_0x3b8e7d, _0x46f211] = await _0x296cc3.jPOim(_0x11efd2, _0x2ccffb, _0x2bb5fd, ..._0x4ffbc9);
              if (_0x3b8e7d) {
                _0x2ccffb.lastUpdated = _0x57f4b2;
                _0x2ccffb.value = _0x46f211;
              }
              return _0x46f211;
            }
            return await new Promise(_0x4f2d83 => setTimeout(() => _0x4f2d83(_0x2ccffb.value), 0));
          }(_0x23f561, ..._0x3ddbed);
        },
        "reset": function (_0x2a2fd7) {
          var _0x2cf897 = _0x38bda3[_0x2a2fd7];
          if (_0x2cf897) {
            _0x2cf897.lastUpdated = 0;
          }
        }
      };
      return _0xa56f2;
    }
    let _0xfb505e = {
      "cache": function (_0x3844b0, _0x31d3a1) {
        const _0x3740f1 = _0x26b991((_0x4ece6d, _0x31dc13, ..._0x49ce34) => _0x3844b0(_0x4ece6d, ..._0x49ce34), _0x31d3a1);
        return {
          "get": function (..._0x42e3d1) {
            return _0x3740f1.get("_", ..._0x42e3d1);
          },
          "reset": function () {
            _0x3740f1.reset("_");
          }
        };
      }
    };
    _0xfb505e.cacheableMap = _0x26b991;
    _0xfb505e.waitForCondition = function (_0x3fb9b6, _0x256b15) {
      return new Promise(_0x1b28e2 => {
        const _0x4cf3de = Date.now();
        const _0x2d9dc1 = setTick(() => {
          const _0x5411af = Date.now() - _0x4cf3de > _0x256b15;
          if (_0x3fb9b6() || _0x5411af) {
            clearTick(_0x2d9dc1);
            return _0x1b28e2(_0x5411af);
          }
        });
      });
    };
    const _0x9a8e18 = Object.assign(_0xfb505e, _0x4d9ae6);
    const _0x1998f6 = {
      "encodePayload": _0x56a42e => {
        try {
          return JSON.stringify(_0x56a42e);
        } catch (_0x5e28d9) {
          console.error("Failed to encode payload");
        }
      },
      "decodePayload": _0x2588fd => {
        try {
          return JSON.parse(_0x2588fd);
        } catch (_0x43416c) {
          console.error("Failed to decode payload");
        }
      }
    };
    const _0x26c8a5 = {
      "on": (_0x4c9087, _0x443be9) => on(_0x4c9087, _0x443be9),
      "onNet": (_0x174e8f, _0x18e1b2) => onNet(_0x174e8f, _0x18e1b2),
      "emit": (_0x3af3e8, ..._0x741780) => {
        emit(_0x3af3e8, ..._0x741780);
      },
      "emitNet": (_0x50a1d9, _0x5d5234, ..._0x4b483a) => {
        const _0x5901aa = msgpack_pack(_0x4b483a);
        if (_0x5901aa.length < 16000) {
          TriggerClientEventInternal(_0x50a1d9, _0x5d5234, _0x5901aa, _0x5901aa.length);
        } else {
          TriggerLatentClientEventInternal(_0x50a1d9, _0x5d5234, _0x5901aa, _0x5901aa.length, 128000);
        }
      },
      "remove": (_0x31f1d4, _0x2fb302) => {
        removeEventListener(_0x31f1d4, _0x2fb302);
      }
    };
    onNet("__cpx_res:" + _0x56af7f, (_0x3ebac1, _0x4c1bfc) => {
      const _0x2d94f5 = _0x282180.get(_0x3ebac1);
      if (undefined === _0x2d94f5) {
        return;
      }
      clearTimeout(_0x2d94f5.timeout);
      const [_0x5e3223, _0x51414d] = _0x4c1bfc;
      if (_0x5e3223) {
        _0x2d94f5.resolve(_0x51414d);
      } else {
        _0x2d94f5.reject(new Error(_0x51414d));
      }
    });
    const _0xb1f2b2 = {
      "register": (_0x483b78, _0x5e73e6) => {
        onNet("__cpx_req:" + _0x483b78, async (_0x2a04d6, _0x1b5adf) => {
          let _0x1238c0;
          let _0x5f91a7;
          console.log("Received request: " + _0x483b78, _0x2a04d6, _0x1b5adf);
          const _0x5b0dfe = _0x1998f6.decodePayload(_0x2a04d6);
          if (undefined === _0x5b0dfe) {
            return console.log("[RPC] Received malformed packet:", _0x2a04d6);
          }
          try {
            _0x1238c0 = await _0x5e73e6(_0x5b0dfe.src, ..._0x1b5adf);
            _0x5f91a7 = true;
          } catch (_0x484adc) {
            _0x1238c0 = _0x484adc;
            _0x5f91a7 = false;
          }
          if ("remote" === _0x5b0dfe.type) {
            _0x26c8a5.emitNet("__cpx_res:" + _0x5b0dfe.origin, _0x5b0dfe.src, _0x5b0dfe.id, [_0x5f91a7, _0x1238c0]);
          } else if ("local" === _0x5b0dfe.type) {
            _0x26c8a5.emit("__cpx_res:" + _0x5b0dfe.origin, _0x5b0dfe.id, [_0x5f91a7, _0x1238c0]);
          }
        });
      },
      "execute": (_0x223a8a, ..._0x18c7fb) => {
        var _0x32914d = {
          id: ++_0x25e784,
          type: "remote",
          origin: _0x56af7f
        };
        const _0x110966 = new Promise((_0x1bd853, _0x28c923) => {
          const _0x163bca = +setTimeout(() => _0x28c923(new Error("Remote call timed out | " + _0x223a8a)), 60000);
          var _0x520190 = {
            resolve: _0x1bd853,
            reject: _0x28c923,
            timeout: _0x163bca
          };
          _0x282180.set(_0x32914d.id, _0x520190);
        });
        _0x26c8a5.emitNet("__cpx_req:" + _0x223a8a, _0x1998f6.encodePayload(_0x32914d), _0x18c7fb);
        _0x110966["finally"](() => _0x282180["delete"](_0x32914d.id));
        return _0x110966;
      }
    };
    let _0x19e78a = {
      Events: _0x26c8a5,
      Procedures: _0xb1f2b2,
      Utils: _0x9a8e18
    };
    _0x2fd61a.g.CPX = _0x19e78a;
    setImmediate(() => {
      _0x2fd61a.g.exports("GetLibrary", () => _0x19e78a);
    });
  }();